#include <gtk/gtk.h>


void
on_bksp_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ce_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_clr_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_plusminus_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_seven_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_eight_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_nine_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_division_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_four_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_five_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_six_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_multiply_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_one_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_two_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_three_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_subtract_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_zero_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_dot_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_total_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_clicked                         (GtkButton       *button,
                                        gpointer         user_data);
